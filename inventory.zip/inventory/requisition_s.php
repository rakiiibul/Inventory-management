<!doctype html>
<html class="no-js" lang="">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        
        <title>             </title>
        
        
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <link rel="apple-touch-icon" href="apple-touch-icon.png">
        <!-- Place favicon.ico in the root directory -->
        
        <link rel="stylesheet" href="css/slicknav.css">
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <link rel="stylesheet" href="css/normalize.css">
        <link rel="stylesheet" href="style.css">
        <script src="js/vendor/modernizr-2.8.3.min.js"></script>
    </head>
    <body>
        <!--HTML START FROM HERE-->
       <div class="full">   

          <div class="topheader">
        <div class="search">
            <input type="text" placeholder="Search.." name="search">
      <button type="submit"><i class="fa fa-search"></i></button></div>
       
        <div class="name">
       
             <h1>STOREKEEPER DASHBOARD</h1>
        </div> 
    </div>
           
        <!--main content Start here--->
        
 <div class="personal_template_wrapper">
		        <div class="container">
		            <div class="row">
		                <div class="menu_sidebar">
		                    <ul>
		                        <li><a class="report" href="report_s.php">REPORT</a></li>
		                        
                                   <li><a class="add_product" href="add_product_s.php">Add Product Information</a></li>
                                   <li><a class="view_product" href="view_product_s.php">view Product</a></li>
                                   <li><a class="update_product" href="update_product_s.php">update Product</a></li>
                                    <li><a class="add_requisition" href="add_requisition_s.php">Add Requisition Management</a></li>
		                        <li><a class="requisition" href="requisition_s.php"> View Requisition</a></li>
                                 <li><a class="update_requisition" href="update_requisition_s.php">Update Requisition</a></li>
		                        
		                    </ul>
		                </div>
		                <div class="menu_details">
		                    
		              
                    
                  
		                    <div class="post_content requisition">
                               
                                 <div class="product">
                                <table style="height:400px; width:600px;" >
  <tr >
      <th>SL</th>
    <th>Activities</th>
    <th colspan="2">Action</th>
 
  </tr>
  <tr>
      <td>01</td>
    <td>Requisition Date</td>
    <td colspan="2">03/02/2019 - 20/08/2019</td>
    
  </tr>
  <tr>
      <td>02</td>
    <td>Requisition ID</td>
   <td><button type="button" class="btn btn-success">Approve</button></td>
    <td><button type="button" class="btn btn-danger">Delete</button></td>
  </tr>
  <tr>
      <td>03</td>
    <td>Product List</td>
     <td colspan="2"><button type="button"  class="btn btn-success">view product</button></td>
   
   
  </tr>
  <tr>
      <td>04</td>
    <td>Requisition Status</td>
      <td><button type="button" class="btn btn-success">Approve</button></td>
    <td><button type="button" class="btn btn-danger">Delete</button></td>
 
  </tr>
  <tr>
      <td>05</td>
    <td>Expected Bill</td>
      <td><button type="button" class="btn btn-success">Approve</button></td>
    <td><button type="button" class="btn btn-danger">Delete</button></td>
    
  </tr>
  
</table>
                                    </div>
                            </div>
		                   
		                   
		                </div>
                        
		            </div>
		        </div>
		    </div>
		    
           <div class="latest_news">
           <h1>latest News</h1>
              
               <marquee behavior="scroll" direction="up">Sint cernantur ne fabulas. Expetendis illum aliquip cernantur, aliqua mandaremus 
                   coniunctione hic et quem proident despicationes an malis aliquip non pariatur 
                   ita sed iudicem e offendit, voluptate quo sint deserunt iis ea eram culpa ubi 
                   vidisse hic deserunt sunt minim eiusmod fugiat. Et ita praetermissum aut laboris 
                   sint non ullamco distinguantur. Iudicem e appellat et vidisse multos magna 
                   tempor anim in nescius ex fugiat, quid possumus senserit si si nulla 
                   graviterque, hic non praetermissum, qui enim philosophari qui culpa arbitrantur 
                   officia aute ullamco. Expetendis quid eram do culpa iis sed multos proident, hic 
                   deserunt ad probant est aliquip o tamen e te nam magna quem l
                   sunt ullamco. Fore aliquip aut voluptatibus, aliquip duis ita occaecat 
                   comprehenderit. E quid mandaremus tractavissent, eu summis id quis. Fugiat ubi 
                   occaecat id veniam ita ut illum eruditionem, non nescius id probant a legam 
                   appellat hic nulla illum. In de lorem deserunt.!</marquee>

           
           </div>
           <!-----FOOTER STRAT HERE----->
  <footer class="footer-dash">

				<p >
					<span>About me</span>
                    @tajbangla<br>
                    tajbangla@official.com
				</p>
 

		</footer> 
        
       
             <!--Script file HERE-->
      
       <!-- larest jquery file calling -->
		<script src="js/vendor/jquery-3.3.1.min.js" type="text/javascript"></script>
        <script src="js/plugins.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/jquery.slicknav.min.js"></script>
        <script src="js/fitbit_client.js"></script>
        <script src="js/main.js"></script>


    </body>
</html>
