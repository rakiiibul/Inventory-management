<?php session_start();

$_SESSION['userid']=$_POST['userid'];
$_SESSION['password']=$_POST['password'];

$con = mysqli_connect("localhost","root","","dbinventory");

$q="select * from tbluser";
//echo $_POST['userid'];
$arr=mysqli_query($con,$q);
if($arr)
{ 
$row=mysqli_fetch_array($arr);
//echo $row['userid'];
if($row['userid']==$_POST['userid']&&$row['password']==$_POST['password'])
	echo "<meta http-equiv=refresh content=0;http://localhost/inventory/report_s.php>";
    else 
	echo 
    "<meta http-equiv=refresh content=0;http://localhost/inventory/index.php>";
}
else
	echo "<meta http-equiv=refresh content=0;http://localhost/inventory/index.php>";

?>