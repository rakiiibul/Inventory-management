
<!doctype html>
<html class="no-js" lang="">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        
        <title>Add_product           </title>
        
        
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <link rel="apple-touch-icon" href="apple-touch-icon.png">
        <!-- Place favicon.ico in the root directory -->
        
        <link rel="stylesheet" href="css/slicknav.css">
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <link rel="stylesheet" href="css/normalize.css">
        <link rel="stylesheet" href="style.css">
        <script src="js/vendor/modernizr-2.8.3.min.js"></script>
    </head>
    <body>
        <!--HTML START FROM HERE-->
       <div class="full">   

          <div class="topheader">
        <div class="search">
            <input type="text" placeholder="Search.." name="search">
      <button type="submit"><i class="fa fa-search"></i></button></div>
       
        <div class="name">
       
             <h1>STOREKEEPER DASHBOARD</h1>
        </div> 
    </div>
           
        <!--main content Start here--->
        
 <div class="personal_template_wrapper">
		        <div class="container">
		            <div class="row">
		                <div class="menu_sidebar">
		                      <ul>
		                        <li><a class="report" href="report_s.php">REPORT</a></li>
		                        
                                   <li><a class="add_product" href="add_product_s.php">Add Product Information</a></li>
                                   <li><a class="view_product" href="view_product_s.php">view Product</a></li>
                                   <li><a class="update_product" href="update_product_s.php">update Product</a></li>
                                    <li><a class="add_requisition" href="add_requisition_s.php">Add Requisition Management</a></li>
		                        <li><a class="requisition" href="requisition_s.php"> View Requisition</a></li>
                                 <li><a class="update_requisition" href="update_requisition_s.php">Update Requisition</a></li>
		                        
		                    </ul>
		                </div>
		                <div class="menu_details add_product ">
		                    
		                    <div class="post_content">
                                <div class="add_product_details"> 
                                
                                
                                
                                
                                
      <form role="form" action="add.php" method="post">
                <div class="form-group">
                  <label style="font-size:25px;">Add Product</label>
                </div>
                <div class="form-group">
                  <label for="product">Product Name</label>
                  <input type="text" class="form-control" id="product" required="" name="pname">
                </div>

                  <div class="form-group">
                  <label for="size"> Product Size</label>
                 <select class="form-control" id="sel1" name="psize">
                     <option value="small">small</option><option value="Medium">Medium</option><option value="Large">Large</option><option value="Extra Large">Extra Large</option>              </select>
                </div>

                 <div class="form-group">
                  <label for="category"> Product Color</label>
                 <select class="form-control" id="sel1" name="pcolor">
                  <option value="Red">Red</option>
                     <option value="Black">Black</option>
                     <option value="White">White</option><option value="Pink">Pink</option>              </select>
                </div>

                   <div class="form-group">
                  <label for="quantity">Quantity</label>
                  <input type="number" class="form-control" id="quantity" name="pquantity" required="">
                </div>

                   <div class="form-group">
                  <label for="pr">Price</label>
                  <input type="number" class="form-control" id="pr" required="" name="pprice">
                       
                            </div>
           <div class="form-group">
                  <label for="product">Product Description</label>
                 <textarea rows="4" cols="50" class="form-control" name="pdescription" id="des" required="">

</textarea>
                </div>
              <div class="form-group">
                  <label for="image">Image</label>
                  
                            
                        <input type="file" class="form-control" name="fileToUpload" id="fileToUpload" required="">
  
           </div>



                <button type="submit" class="btn btn-primary" name="add_product">Save</button>
            </form>

  
                                  
                      </div>
                        </div>
                  
		                </div>
                        
		            </div>
		        </div>
		    </div>
		    
           <div class="latest_news">
           <h1>latest News</h1>
              
               <marquee behavior="scroll" direction="up">Sint cernantur ne fabulas. Expetendis illum aliquip cernantur, aliqua mandaremus 
                   coniunctione hic et quem proident despicationes an malis aliquip non pariatur 
                   ita sed iudicem e offendit, voluptate quo sint deserunt iis ea eram culpa ubi 
                   vidisse hic deserunt sunt minim eiusmod fugiat. Et ita praetermissum aut laboris 
                   sint non ullamco distinguantur. Iudicem e appellat et vidisse multos magna 
                   tempor anim in nescius ex fugiat, quid possumus senserit si si nulla 
                   graviterque, hic non praetermissum, qui enim philosophari qui culpa arbitrantur 
                   officia aute ullamco. Expetendis quid eram do culpa iis sed multos proident, hic 
                   deserunt ad probant est aliquip o tamen e te nam magna quem l
                   sunt ullamco. Fore aliquip aut voluptatibus, aliquip duis ita occaecat 
                   comprehenderit. E quid mandaremus tractavissent, eu summis id quis. Fugiat ubi 
                   occaecat id veniam ita ut illum eruditionem, non nescius id probant a legam 
                   appellat hic nulla illum. In de lorem deserunt.!</marquee>

           
           </div>
           <!-----FOOTER STRAT HERE----->
  <footer class="footer-dash">

				<p >
					<span>About me</span>
                    @tajbangla<br>
                    tajbangla@official.com
				</p>
 

		</footer> 
        
        </div>
             <!--Script file HERE-->
      
       <!-- larest jquery file calling -->
		<script src="js/vendor/jquery-3.3.1.min.js" type="text/javascript"></script>
        <script src="js/plugins.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/jquery.slicknav.min.js"></script>
        <script src="js/fitbit_client.js"></script>
        <script src="js/main.js"></script>


    </body>
</html>
