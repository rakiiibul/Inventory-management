<?php
$con = new mysqli("localhost", "root", "", "dbinventory");

$sql = "delete from tblproduct where pid=$_GET[pid]";
mysqli_query($con,$sql);
header("Location:http://localhost/inventory/view_product_s.php");
?>

