<!doctype html>
<html class="no-js" lang="">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        
        <title>             </title>
        
        
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <link rel="apple-touch-icon" href="apple-touch-icon.png">
        <!-- Place favicon.ico in the root directory -->
        
        <link rel="stylesheet" href="css/slicknav.css">
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <link rel="stylesheet" href="css/normalize.css">
        <link rel="stylesheet" href="style.css">
        <script src="js/vendor/modernizr-2.8.3.min.js"></script>
    </head>
    <body>
        <!--HTML START FROM HERE-->
       <div class="full">   

          <div class="topheader">
        <div class="search">
            <input type="text" placeholder="Search.." name="search">
      <button type="submit"><i class="fa fa-search"></i></button></div>
       
        <div class="name">
       
             <h1>STOREKEEPER DASHBOARD</h1>
        </div> 
    </div>
           
        <!--main content Start here--->
        
 <div class="personal_template_wrapper">
		        <div class="container">
		            <div class="row">
		                <div class="menu_sidebar">
		                       <ul>
		                         <li><a class="report" href="report_s.php">REPORT</a></li>
		                        
                                   <li><a class="add_product" href="add_product_s.php">Add Product Information</a></li>
                                   <li><a class="view_product" href="view_product_s.php">view Product</a></li>
                                   <li><a class="update_product" href="update_product_s.php">update Product</a></li>
                                    <li><a class="add_requisition" href="add_requisition_s.php">Add Requisition Management</a></li>
		                        <li><a class="requisition" href="requisition_s.php"> View Requisition</a></li>
                                 <li><a class="update_requisition" href="update_requisition_s.php">Update Requisition</a></li>
		                        
		                    </ul>
		                </div>
		                <div class="menu_details ">
		                    
		                    
                  
		               
		                    <div class="post_content">
                                 <div class="report_deatails">
                    
                          <h4 >Invoice</h4>
                          <a href="#"><small>Show All</small></a>
                        
                       
                          <table>
                            <thead>
                              <tr>
                                <th>Invoice ID</th>
                                <th>Product</th>
                                <th>Status</th>
                                <th>Qantity</th>
                                <th>Due Date</th>
                                <th>Amount</th>
                              </tr>
                            </thead>
                            <tbody>
                              <tr>
                                <td>INV-87230</td>
                                <td>Shirt</td>
                                <td>Paid</td>
                                <td>120</td>
                                <td>20 Jan 2019</td>
                                <td>$7,655</td>
                              </tr>
                              <tr>
                                <td>INV-87235</td>
                                <td>Pant</td>
                                <td>Unpaid</td>
								<td>100</td>
                                <td>23 Feb 2019</td>
                                <td>$8,700</td>
                              </tr>
                              <tr>
                                <td>INV-87234</td>
                                <td>Panjabi</td>
                                <td>Unpaid</td>
									<td>80</td>
                                <td>25 Mar 2019</td>
                                <td>$4,603</td>
                              </tr>
                              <tr>
                                <td>INV-87239</td>
                                <td>Tshirt</td>
                                <td>Paid</td>
									<td>130</td>
                                <td>27 Mar 2019</td>
                                <td>$2,935</td>
                              </tr>
                              <tr>
                                <td>INV-84234</td>
                                <td>Blazzer</td>
                                <td>Unpaid</td>
									<td>100</td>
                                <td>1 Apr 2019</td>
                                <td>$10,657</td>
                              </tr>
                            </tbody>
                          </table>
                        </div>
                                
                                <div class="total1">
                                    <h4 style="text-align:center;">Total Product</h4>
                                    <h2 style="text-align:center;">1700</h2></div>
                                <div class="total2"><h4 style="float:center;text-align:center;">Total Sales</h4><h2 style="color:green;text-align:center;">1100</h2></div>
                                <div class="total3"><h4>Total Amount</h4><h2>$60,560</h2></div>
                                <div class="total4">
                                
                                <h4 style="text-align:center;">Total Revenue</h4>
                                    <h2 style="text-align:center;">$30,000</h2>
                                
                                </div>
                       
                            </div>
		                   
		                </div>
                        
		            </div>
		        </div>
		    </div>
		    
           <div class="latest_news">
           <h1>latest News</h1>
              
               <marquee behavior="scroll" direction="up">Sint cernantur ne fabulas. Expetendis illum aliquip cernantur, aliqua mandaremus 
                   coniunctione hic et quem proident despicationes an malis aliquip non pariatur 
                   ita sed iudicem e offendit, voluptate quo sint deserunt iis ea eram culpa ubi 
                   vidisse hic deserunt sunt minim eiusmod fugiat. Et ita praetermissum aut laboris 
                   sint non ullamco distinguantur. Iudicem e appellat et vidisse multos magna 
                   tempor anim in nescius ex fugiat, quid possumus senserit si si nulla 
                   graviterque, hic non praetermissum, qui enim philosophari qui culpa arbitrantur 
                   officia aute ullamco. Expetendis quid eram do culpa iis sed multos proident, hic 
                   deserunt ad probant est aliquip o tamen e te nam magna quem l
                   sunt ullamco. Fore aliquip aut voluptatibus, aliquip duis ita occaecat 
                   comprehenderit. E quid mandaremus tractavissent, eu summis id quis. Fugiat ubi 
                   occaecat id veniam ita ut illum eruditionem, non nescius id probant a legam 
                   appellat hic nulla illum. In de lorem deserunt.!</marquee>

           
           </div>
           <!-----FOOTER STRAT HERE----->
  <footer class="footer-dash">

				<p >
					<span>About me</span>
                    @tajbangla<br>
                    tajbangla@official.com
				</p>
 

		</footer> 
        
        </div>
             <!--Script file HERE-->
      
       <!-- larest jquery file calling -->
		<script src="js/vendor/jquery-3.3.1.min.js" type="text/javascript"></script>
        <script src="js/plugins.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/jquery.slicknav.min.js"></script>
        <script src="js/fitbit_client.js"></script>
        <script src="js/main.js"></script>


    </body>
</html>
