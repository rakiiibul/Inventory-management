<html>
  <body>
  <?php
   $con=mysqli_connect("localhost", "root", "", "dbinventory");
   $query="select * from tblproduct where pid=$_GET[pid]";
   $data=mysqli_query($con,$query );
    $r=mysqli_fetch_array($data);
	?>
   <form action="update.php" method="post">
   <table>
      <tr><td>student ID:</td><td><input type="text" name="sid"value="<?php echo $r['sid'];?>"disabled>
	  <input type="hidden" name="sid" value="<?php echo $r['sid'];?>"></td></tr>
       <tr><td>student Password:</td><td><input type="text" name="spass"value="<?php echo $r['spass'];?>"></td></tr>
       <tr><td>student Name:</td><td><input type="text" name="sname"value="<?php echo $r['sname'];?>"></td></tr>
      <tr><td>student Email:</td><td><input type="text" name="semail"value="<?php echo $r['semail'];?>"></td></tr>
    <tr><td>student batch:</td><td><input type="text" name="sbatch"value="<?php echo $r['sbatch'];?>"></td></tr>
     <tr align="right"><td colspan="2"><input type="submit" value="update"></td></tr>
   </table>
  
  
  </body>
</html>