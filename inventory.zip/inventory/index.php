<html>
<head>
    <title>Login</title>
    <link rel="stylesheet" type="text/css" href="css/style.css"/>
    
    </head>

<body>
    <div class="full">
   <div class="logo">
   
    </div>
    <div class="login">
<h3>LOGIN</h3>
        <form action="login.php" method="post">
            <p>User ID:</p> <input type="text" name="userid" placeholder="userid"/>
        <p>password:</p>
            <input type="input100" type="password" name="password" placeholder="password"><br/>
            
           <div class="submit"> <input type="submit" value="Login">
            </div>
            
        </form>
        
        <strong style="margin:15px;">Recover your account?<a href="Registration.php">Recover Here</a></strong>      
    
    
    </div>
    
    
    </div>
    
    
    </body>
</html>