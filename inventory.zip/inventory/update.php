<?php
$conn = new mysqli("localhost", "root", "", "dbinventory");


$sql = "UPDATE tblproduct SET pname = '$_POST[pname]',psize = '$_POST[psize]',pquantity = '$_POST[pquantity]' ,pprice = '$_POST[pprice]',pdescription = '$_POST[pdescription]' WHERE tblproduct.pid = '$_POST[pid]'";

mysqli_query($conn,$sql);


header("Location:http://localhost/inventory/view_product_s.php");
?>