<?php 

   $con = mysqli_connect("localhost",'root',"","dbinventory") or die ('Connection Error !!');
?>