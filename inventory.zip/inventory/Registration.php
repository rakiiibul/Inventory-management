<html>
<head>
    <title>Recover Password</title>
    <link rel="stylesheet" type="text/css" href="css/style.css"/>
    
    </head>

<body>
    <div class="full">
  
    <div class="login">
        
    <h4>Recover ID</h4>
        
        <form action="recover.php" method="post">
            <p>Your Email:</p> <input type="text" name="userid"/>
        <p>Old password:</p>
            <input type="password" name="password"/><br/>
             <p>New password:</p>
            <input type="password" name="pass"/><br/>
            
           <div class="submit"> <input type="submit" value="UPDATE">
            </div>
        </form>
        
            
    
    
    </div>
    
    
    </div>
    
    
    </body>
</html>