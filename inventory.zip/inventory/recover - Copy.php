 <?php
$conn = new mysqli("localhost", "root", "", "dbinventory");


echo $_POST['userid']." ";
echo $_POST['password']." ";

$sql = "INSERT INTO tbluser VALUES ('$_POST[userid]', '$_POST[password]')";


$conn->query($sql);
header("Location:http://localhost/inventory/index.php");

?> 