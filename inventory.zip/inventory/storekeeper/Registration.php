<html>
<head>
    <title>Recover Password</title>
    <link rel="stylesheet" type="text/css" href="css/style.css"/>
    
    </head>

<body>
    <div class="full">
  
    <div class="login">
        
    <h4>Recover ID</h4>
        
        <form>
            <p>Your Email:</p> <input type="text" name="email"/>
        <p>Old password:</p>
            <input type="password" name="pass"/><br/>
             <p>New password:</p>
            <input type="password" name="pass"/><br/>
            
           <div class="submit"> <a href="index.php"><button type="button">Update </button></a>
            </div>
        </form>
        
            
    
    
    </div>
    
    
    </div>
    
    
    </body>
</html>