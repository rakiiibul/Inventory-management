    <?php
   
     $pname = filter_input(INPUT_POST,'pname');
     $psize = filter_input(INPUT_POST,'psize');
     $pcolor = filter_input(INPUT_POST,'pcolor');
     $pquantity = filter_input(INPUT_POST,'pquantity');
     $pprice = filter_input(INPUT_POST,'pprice');
     $pdescription = filter_input(INPUT_POST,'pdescription');
    $host = "localhost";
    $dbusername = "root";
    $dbpassword = "";
    $dbname = "dbinventory";
    // Create connection
   $conn = mysqli_connect("localhost","root","","dbinventory");

    if (mysqli_connect_error()){
    die('Connect Error ('. mysqli_connect_errno() .') '
    . mysqli_connect_error());
    }
    else{
    $sql = "INSERT INTO tblproduct (pname,psize,pcolor,pquantity,pprice,pdescription)
    values ('$pname','$psize','$pcolor','$pquantity','$pprice','$pdescription')";
    if ($conn->query($sql)){
    echo "<meta http-equiv=refresh content=0;http://localhost/inventory/view_product_s.php>";
    }
    else{
    echo "Error: ". $sql ."
    ". $conn->error;
    }
    $conn->close();
    }

    ?>
